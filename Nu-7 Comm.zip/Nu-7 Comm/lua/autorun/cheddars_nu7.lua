player_manager.AddValidModel( "Nu-7 Enlisted", "models/player/cheddar/mtf/nu7/nu7_enlisted.mdl" )
player_manager.AddValidHands( "Nu-7 Enlisted", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Nu-7 Marksman", "models/player/cheddar/mtf/nu7/nu7_marksman.mdl" )
player_manager.AddValidHands( "Nu-7 Marksman", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Nu-7 Medic", "models/player/cheddar/mtf/nu7/nu7_medic.mdl" )
player_manager.AddValidHands( "Nu-7 Medic", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Nu-7 Autorifleman", "models/player/cheddar/mtf/nu7/nu7_autorifleman.mdl" )
player_manager.AddValidHands( "Nu-7 Autorifleman", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Nu-7 Officer", "models/player/cheddar/mtf/nu7/nu7_officer.mdl" )
player_manager.AddValidHands( "Nu-7 Officer", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Nu-7 Commander", "models/player/cheddar/mtf/nu7/nu7_commander.mdl" )
player_manager.AddValidHands( "Nu-7 Commander", "models/player/cheddar/mtf/nu7/nu7_arms.mdl", 0, "00000000" )
